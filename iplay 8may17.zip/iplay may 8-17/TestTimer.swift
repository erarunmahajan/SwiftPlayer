//
//  TestTimer.swift
//  Iplay
//
//  Created by Student2 on 07/04/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

class TestTimer: UIViewController {
    
    let Vc: ViewController? = ViewController()
   @IBOutlet weak var makeHIde: UIButton!
    @IBOutlet weak var pause: UIButton!
    @IBOutlet weak var Reset: UIButton!
    var value:Int?
    var secs:Int?
    var time = 0
    var timer = Timer()
    var min: Int? = 0
    //@IBOutlet weak var labl: UILabel!
    @IBOutlet weak var lablmin: UILabel!
    
    @IBOutlet weak var lablesecs: UILabel!
   // @IBOutlet weak var lablemins: UILabel!
    @IBOutlet weak var textValue: UITextField!
            override func viewDidLoad() {
        super.viewDidLoad()
            
         
                
        self.pause.isHidden = true ; self.Reset.isHidden = true
       
        self.lablmin.isHidden = true
      
        self.lablesecs.isHidden = true
        // Do any additional setup after loading the view.
    }
   override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func pause(_ sender: UIButton) {
      
      timer.invalidate()
      self.makeHIde.isHidden = false
        self.lablmin.isHidden = false
        
    }
     @IBAction func Reset(_ sender: UIButton) {
      timer.invalidate()
        time = 0
        lablmin.text = "0"
        self.makeHIde.isHidden = false
        self.textValue.isEnabled = true
    }
        @IBAction func start(_ sender: UIButton)
        {
        value = Int(textValue.text!)!
        secs = value! * 60
        if value! < 1
        {
            let alert = UIAlertController (title: "Swift Player Timer SetUp", message: "Please check the values for timer", preferredStyle: .alert)
            let ok = UIAlertAction (title: "Ok", style: .default, handler: { (action: UIAlertAction!) in self.textValue.becomeFirstResponder(); self.textValue.text! = "0";  })
                    alert.addAction(ok)
                    present(alert, animated:true)
        }
        else
        {
            let alert = UIAlertController (title: "Swift Player Timer", message: "Swift Player will be stopped after \(value!) min(s)", preferredStyle: .alert)
            let ok = UIAlertAction (title: "Ok", style: .default, handler: { (action: UIAlertAction!) in self.textValue.isEnabled = false; self.makeHIde.isHidden = true; self.pause.isHidden = false; self.Reset.isHidden = false ; })
            alert.addAction(ok)
            present(alert, animated:true)
    
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TestTimer.timerStart), userInfo: nil, repeats: true)
            
            self.textValue.text = "0"
        }
    }
     func timerStart()
     {
        time += 1
        self.lablmin.isHidden = false
        self.lablesecs.isHidden = false
        self.lablmin.text =   String(secs! - time)
        if (time == secs)
        {
            timer.invalidate()
            time = 0
            Vc?.mp.pause()
            exit(0)
        }
    }
}
