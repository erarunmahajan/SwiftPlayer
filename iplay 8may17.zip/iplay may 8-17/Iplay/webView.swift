//
//  webView.swift
//  Iplay
//
//  Created by Student2 on 30/03/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

class webView: UIViewController {

    @IBOutlet var url: UITextField!
   
    @IBOutlet var www: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        www.loadRequest(NSURLRequest(url:NSURL(string: "http://google.com")! as URL) as URLRequest)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func search(_ sender: Any) {
        
        www.loadRequest(NSURLRequest(url:NSURL(string: "http://" + url.text! + "/")! as URL) as URLRequest)
        if url.text == ""
        {
        www.loadRequest(NSURLRequest(url:NSURL(string: "")! as URL) as URLRequest)
        
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func reload(_ sender: Any)
    {
        www.loadRequest(NSURLRequest(url:NSURL(string: "http://google.com" + "/" + url.text! + "/")!as URL) as URLRequest)
        
 
        
        
    }
   

}
