//
//  radioViewController.swift
//  Iplay
//
//  Created by Student1 on 05/05/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

class radioViewController: UIViewController {
    
    @IBOutlet weak var radioWeb: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        radioWeb.isHidden = true
        radioWeb.allowsInlineMediaPlayback = true;
        self.tabBarController?.tabBar.isHidden  = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func playRadio(_ sender: AnyObject)
    {
         radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://www.abc.net.au/res/streaming/audio/mp3/news_radio.pls")! as URL) as URLRequest)
        /*"http://rfcmedia.streamguys1.com/classicrock.mp3"*/
    }
    
    
    @IBAction func Soundsof80s(_ sender: AnyObject)
    {
        radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio1_mf_p")! as URL) as URLRequest)
    }
    
    @IBAction func sunPopRadio(_ sender: AnyObject) {
        radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://djboyradio.streamguys1.com/sub-pop-records.mp3")! as URL) as URLRequest)
    }
   
    
    @IBAction func classicRock(_ sender: AnyObject) {
        
        radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://rfcmedia.streamguys1.com/classicrock.mp3")! as URL) as URLRequest)
    }
    @IBAction func radio1190(_ sender: AnyObject) {
        
        radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://www.bbc.co.uk/radio/listen/live/r5lsp_aaclca.pls")! as URL) as URLRequest)
    }
   
    
    @IBAction func stop(_ sender: AnyObject) {
        radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "")! as URL) as URLRequest)
    }
    
    @IBAction func bbc2(_ sender: AnyObject) {
         radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio2_mf_p")! as URL) as URLRequest)
        
    }
   
    @IBAction func bbc3(_ sender: AnyObject) {
         radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://open.live.bbc.co.uk/mediaselector/5/select/version/2.0/mediaset/http-icy-aac-lc-a/format/pls/vpid/bbc_radio_three.pls")! as URL) as URLRequest)
        
    }
    
    @IBAction func bbc4(_ sender: AnyObject) {
          radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio4fm_mf_p")! as URL) as URLRequest)
    }
    
    @IBAction func bbc5(_ sender: AnyObject) {
          radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio5live_mf_p")! as URL) as URLRequest)
    }
    
    @IBAction func bbc6(_ sender: AnyObject) {
          radioWeb.loadRequest(NSURLRequest(url:NSURL(string: "http://bbcmedia.ic.llnwd.net/stream/bbcmedia_6music_mf_p")! as URL) as URLRequest)
    }
    
    
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
