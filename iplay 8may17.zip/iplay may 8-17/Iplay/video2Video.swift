//
//  video2Video.swift
//  Iplay
//
//  Created by Student1 on 29/04/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

class video2Video: UIViewController {
    
    @IBOutlet weak var videoToPlay: DesignabbleButton!
    
    @IBAction func playToVideo(_ sender: DesignabbleButton) {
        let openAppURL: String = "Videos://"
        UIApplication.shared.openURL(URL(string: openAppURL)!)
         }
    
    @IBOutlet weak var new: UIButton!
    
    @IBAction func connect(_ sender: UIButton) {
        
        let sb = UIStoryboard(name: "test", bundle: nil)
        let vc2 = sb.instantiateInitialViewController()! as UIViewController
        present(vc2, animated: false, completion: nil)
    }
    
    
    
    
    }
