//
//  Search_tableViewTableViewController.swift
//  Iplay
//
//  Created by Student2 on 04/04/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

class search_TableView: UITableViewController, UISearchResultsUpdating {
    
    var search = ["songs", "ball", "ayodya", "chanda", "ded de", "elephant", "farsio", "grahk", "kites", "qota", "wax", "vin", "opas"]
    var filtersearch = [String]()
    var  searchController : UISearchController!
    var results = UITableViewController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.results.tableView.dataSource = self
        self.results.tableView.delegate = self
        self.searchController = UISearchController(searchResultsController: self.results)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        self.tableView.tableHeaderView = self.searchController.searchBar
        self.searchController.searchResultsUpdater = self
        self.searchController.dimsBackgroundDuringPresentation = false
    }
    
    
    func updateSearchResults(for searchController: UISearchController)
    {
        //filter through the songs
        self.filtersearch =  self.search.filter {(search: String) ->Bool in
            if search.lowercased().contains(self.searchController.searchBar.text!.lowercased()){
                
                return true
                
            } else{ return false}
        }
        
        self.results.tableView.reloadData()
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == self.tableView{
            
            return self.search.count}
        else{ return self.filtersearch.count}
        
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        if tableView == self.tableView{
            
            cell.textLabel?.text = self.search[indexPath.row]
        }
            
        else{
            cell.textLabel?.text = self.filtersearch[indexPath.row]
        }
        
        return cell
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
