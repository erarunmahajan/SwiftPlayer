//
//  video.swift
//  Iplay
//
//  Created by Student2 on 25/04/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit


class video: UIViewController{
    
    
    @IBOutlet var utube: UIWebView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        utube.loadRequest(NSURLRequest(url:NSURL(string: "https://www.youtube.com")! as URL) as URLRequest)
        
    }
    
    @IBOutlet weak var refresh: UIBarButtonItem!
       
    @IBAction func refres(_ sender: AnyObject) {
        utube.reload()
    }
    @IBAction func back(_ sender: AnyObject) {
        utube.goBack()
    }
    
    
   
    
    @IBAction func exitApp(_ sender: UIBarButtonItem) {

        utube.goForward()
        
    }

    
    
    
}
