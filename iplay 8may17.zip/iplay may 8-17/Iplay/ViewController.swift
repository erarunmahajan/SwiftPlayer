//
//  ViewController.swift
//  Iplay
//
//  Created by Student2 on 27/03/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//
import Social
import UIKit
import MediaPlayer

//import FacebookLogin

class ViewController: UIViewController,  MPMediaPickerControllerDelegate {

    let mp = MPMusicPlayerController.systemMusicPlayer()
    var link :String=String()
    var link2 : String = String()
    var timer = Timer()
    
    var mediapicker1: MPMediaPickerController!
   
    @IBOutlet weak var btnPause: UIButton!
    @IBOutlet weak var btnPlay: UIButton!
    
    @IBOutlet weak var radio: UIBarButtonItem!
    
    @IBOutlet var imageAlbum: UIImageView!
    
    @IBOutlet weak var labelTitle: UILabel!//Above SLider
    
    @IBOutlet weak var labelDuration: UILabel!
    
    @IBOutlet weak var labelElapsed: UILabel!//lft slider
    
    @IBOutlet weak var vis: UIImageView!
       
    @IBOutlet weak var vis2: UIImageView!
    @IBOutlet weak var vis1: UIImageView!
    @IBOutlet weak var labelRemaining: UILabel!// right of slider
    @IBOutlet weak var sliderTime: UISlider!
    
    
    @IBAction func startRadio(_ sender: AnyObject) {
//       let openAppURL: String = "com.mathewfetcher.SwiftRadio://"
//        UIApplication.shared.openURL(URL(string: openAppURL)!)
    }
    
    
    @IBOutlet var menuButton: UIBarButtonItem!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        mp.pause()
        
        let color : UIColor = UIColor.white
        self.sliderTime.thumbTintColor = color;
        vis.stopAnimating()
        vis1.stopAnimating()
        vis2.stopAnimating()
    sliderTime.setThumbImage(UIImage(named: "Swift-20")!, for: .normal)
        // creating the wrapper view for volume controller
        let wrapperView = UIView(frame: CGRect(x:15, y:490, width:290, height:20))
        self.view.backgroundColor = UIColor.clear
        self.view.addSubview(wrapperView)
        self.view.tintColor = UIColor.red
        self.view.bottomAnchor.accessibilityActivate()
        //adding the subview wrapper to main view
        let volumeView = MPVolumeView(frame: wrapperView.bounds)
        wrapperView.addSubview(volumeView)
        
        //reveal view controller
       /* if revealViewController() != nil
        {
              revealViewController().rearViewRevealWidth = 150
           menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rightViewRevealWidth = 150
    view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
 
        } */
        // Do any additional setup after loading the view, typically from a nib.
       //calls timer and related functions when view is first loaded to avoiding waiting for playback change notificaitons
        mp.prepareToPlay()
        
        self.timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(ViewController.timerFired(_:)), userInfo: nil, repeats: true)
        self.timer.tolerance = 0.1
        
        // Add a notification observer for MPMusicPlayerControllerNowPlayingItemDidChangeNotification that fires a method when the track changes (to update track info label)
        mp.beginGeneratingPlaybackNotifications()
        
        NotificationCenter.default.addObserver(self, selector:#selector(ViewController.updateNowPlayingInfo), name: NSNotification.Name.MPMusicPlayerControllerNowPlayingItemDidChange, object: nil)
        
        //Declare media picker for later display
        let mediaPicker: MPMediaPickerController = MPMediaPickerController.self(mediaTypes:MPMediaType.music)
        mediaPicker.allowsPickingMultipleItems = true
        mediapicker1 = mediaPicker
        mediaPicker.delegate = self
createNowPlayingAnimation()
        
    }
    
    //animating Bars
    func createNowPlayingAnimation(){
    vis.animationImages = AnimationFrames.createFrames()
    vis.animationDuration = 0.6
        vis1.animationImages = AnimationFrames.createFrames()
        vis1.animationDuration = 0.5
        vis2.animationImages = AnimationFrames.createFrames()
        vis2.animationDuration = 0.7
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
        // Do any additional setup after loading the view.

    func timerFired(_:AnyObject) {
        
        //Ensure the track exists before pulling the info
        if let currentTrack = MPMusicPlayerController.systemMusicPlayer().nowPlayingItem {
            
            //pull artist and title for current track and show in labelTitle
            let trackName = currentTrack.title!
            link = trackName
            let trackArtist :String!
            var trackArtistDefault : String?
            trackArtistDefault = "No Artist Found"
            
            trackArtist = currentTrack.artist
           //link2 = currentTrack.artist!
           if trackArtist != nil
           {
            labelTitle.text = "\(trackArtist!) \n  \(trackName)"
            }
            else
           {
            labelTitle.text = "\(trackArtistDefault) \n  \(trackName)"
            }
           // labelTitle.text = "\(trackArtist!) \n  \(trackName)"
            
            //set image to Album Artwork
            let albumImage = currentTrack.artwork?.image(at: imageAlbum.bounds.size)
            
            imageAlbum.image = albumImage
            
            //full length of current track in seconds
            //let trackDuration = currentTrack.valueForProperty(MPMediaItemPropertyPlaybackDuration) as! Int
            let trackDuration = currentTrack.playbackDuration
            
            //Convert length in seconds to length in minutes as an Int. Ex. 245 second song is 4.08333 minutes (4:05), this results in 4
            let trackDurationMinutes = Int(trackDuration / 60)
            
            //Find the remainder from the previous equation. 245 / 60 is 4 with a remainder of 5. This results in 5
            let trackDurationSeconds = Int(trackDuration.truncatingRemainder(dividingBy: 60))
            
            //Create the lable for the length of the song. BUT a 4 minute long song with a 5 second remainder would show as "4:5" so..
            if trackDurationSeconds < 10 {
                
                //add a 0 if the number of seconds is less than 10
                labelDuration.text = "Length: \(trackDurationMinutes):0\(trackDurationSeconds)"
                
            } else {
                
                //if more than 10, display as is
                labelDuration.text = "Length: \(trackDurationMinutes):\(trackDurationSeconds)"
            }
            
            //Find elapsed time by pulling currentPlaybackTime
            let trackElapsed = mp.currentPlaybackTime
            
            // avoid crash
            if trackElapsed.isNaN
            {
                return
            }
            
            //Repeat same steps to display the elapsed time as we did with the duration
            let trackElapsedMinutes = Int(trackElapsed / 60)
            
            let trackElapsedSeconds = Int(trackElapsed.truncatingRemainder(dividingBy: 60))
            
            if trackElapsedSeconds < 10 {
                
                labelElapsed.text = "\(trackElapsedMinutes):0\(trackElapsedSeconds)"
                
            } else {
                
                labelElapsed.text = "\(trackElapsedMinutes):\(trackElapsedSeconds)"
                
            }
            
            //Find remaining time by subtraction the elapsed time from the duration
            let trackRemaining = Int(trackDuration) - Int(trackElapsed)
            
            //Repeat same steps to display remaining time
            let trackRemainingMinutes = trackRemaining / 60
            
            let trackRemainingSeconds = trackRemaining % 60
            
            if trackRemainingSeconds < 10 {
                labelRemaining.text = "\(trackRemainingMinutes):0\(trackRemainingSeconds)"
            } else {
                labelRemaining.text = "\(trackRemainingMinutes):\(trackRemainingSeconds)"
            }
            
            //set maximum value of the slider
            sliderTime.maximumValue = Float(trackDuration)
            
            //changes slider to as song progresses
            sliderTime.value = Float(trackElapsed)
            
        }
        
    }
    
    // Create function to change labels to current track info based on previous notification observer
    func updateNowPlayingInfo(){
        
        self.timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(ViewController.timerFired(_:)), userInfo: nil, repeats: true)
        self.timer.tolerance = 0.1
        
    }
    
    
    @IBAction func sliderTimeChanged(_ sender: Any) {
        mp.currentPlaybackTime = TimeInterval(sliderTime.value)
    }
    
    @IBAction func btnPlayImage(_ sender: SpringButton) {
        playButtonEnable(enabled: false)
        mp.play()
        
        
        if let currentTrack = MPMusicPlayerController.systemMusicPlayer().nowPlayingItem{
            vis.startAnimating();
            vis1.startAnimating();
            vis2.startAnimating()
        }
        else{ vis.stopAnimating(); vis.image = UIImage(named: "NowPlayingBars"); }
    }
    
    
    
    
    @IBAction func buttonPlay(_ sender: Any) {
        
        playButtonEnable(enabled: false)
        mp.play()
       

        if let currentTrack = MPMusicPlayerController.systemMusicPlayer().nowPlayingItem{
        vis.startAnimating();
            vis1.startAnimating();
            vis2.startAnimating()
        }
        else{ vis.stopAnimating(); vis.image = UIImage(named: "NowPlayingBars"); }
    }

    @IBAction func buttonPause(_ sender: Any) {
    playButtonEnable()
    mp.pause()
    vis.stopAnimating()
        vis1.stopAnimating()
        vis2.stopAnimating()
    }
    
    @IBAction func buttonPrevious(_ sender: Any) {
       
        mp.skipToPreviousItem()
        
    }
    @IBAction func buttonBeginning(_ sender: Any) {
       
        mp.skipToBeginning()
    }
    @IBAction func buttonNext(_ sender: Any) {
       
        mp.skipToNextItem()
    }
    
    @IBAction func buttonPick(_ sender: Any) {
        mediapicker1 = MPMediaPickerController.self(mediaTypes:MPMediaType.music)
        mediapicker1.allowsPickingMultipleItems = true
        mediapicker1.delegate = self
        self.present(mediapicker1, animated: true, completion: nil)
    }
    
    
    @IBAction func share(_ sender: AnyObject) {
        let activityuc=UIActivityViewController(activityItems: [ "Hey Iam Listening the song:",link,link2], applicationActivities: nil)
        activityuc.popoverPresentationController?.sourceView=self.view
    
        
        self.present(activityuc,animated:true,completion: nil)
    }
               func mediaPicker(_ mediaPicker: MPMediaPickerController, didPickMediaItems mediaItemCollection: MPMediaItemCollection) {
        self.dismiss(animated: true, completion: nil)
        let selectedSongs = mediaItemCollection
        
        mp.setQueue(with: selectedSongs)
        mp.play()
    }
    

    func mediaPickerDidCancel(_ mediaPicker: MPMediaPickerController)
    {
        self.dismiss(animated: true, completion: nil)
    }

    func playButtonEnable(enabled: Bool = true) {
        if enabled {
            btnPlay.isEnabled = true
            btnPause.isEnabled = false
            mp.pause()
            } else {
            btnPlay.isEnabled = false
            btnPause.isEnabled = true
            mp.play()
            
        }
    }
 
    
}

