//
//  AboutViewController.swift
//  Swift Radio
//
//  Created by Matthew Fecher on 7/9/15.
//  Copyright (c) 2015 MatthewFecher.com. All rights reserved.
//

import UIKit
import MessageUI

class AboutViewController: UIViewController {
    
    //*****************************************************************
    // MARK: - ViewDidLoad
    //*****************************************************************
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden  = true
    
    }
   
    //*****************************************************************
    // MARK: - IBActions
    //*****************************************************************
   //Arun Profile
    @IBAction func fbArun(_ sender: UIButton) {
        if let url = URL(string: "https://www.facebook.com/er.arun.mahajan") {
            UIApplication.shared.openURL(url)}
    }
    
    
    
    @IBAction func twiterArun(_ sender: UIButton) {
        if let url = URL(string: "https://twitter.com/Arunmahajan105") {
            UIApplication.shared.openURL(url)}
        
    }
    
    @IBAction func instaArun(_ sender: UIButton) {
        if let url = URL(string: "https://instagram.com/er.arun.mahajan") {
            UIApplication.shared.openURL(url)}
    }
    
    //karan profile
    
    @IBAction func fbKaran(_ sender: AnyObject) {
        if let url = URL(string: "https://www.facebook.com/gupta.passion") {
            UIApplication.shared.openURL(url)}
    }
    
    @IBAction func twiterKaran(_ sender: AnyObject) {
        if let url = URL(string: "https://twitter.com/VishavGupta9") {
            UIApplication.shared.openURL(url)}
    }
    
    @IBAction func instaKaran(_ sender: AnyObject) {
        if let url = URL(string: "https://instagram.com/karan3996") {
            UIApplication.shared.openURL(url)}
    }
   
    //vishav Profile
    @IBAction func fbVishav(_ sender: AnyObject) {
        if let url = URL(string: "https://www.facebook.com/https://www.facebook.com/vishav.gupta.180") {
            UIApplication.shared.openURL(url)}
    }
    
    @IBAction func twiterVishav(_ sender: AnyObject) {
        if let url = URL(string: "https://twitter.com/vihavgupta9") {
            UIApplication.shared.openURL(url)}
    }
    
    @IBAction func instaVishav(_ sender: AnyObject) {
        if let url = URL(string: "https://www.instagram.com/guptavishav9/") {
            UIApplication.shared.openURL(url)}
    }
    
    
    @IBAction func mailToArun(_ sender: UIButton) {
        let receipients = ["er.arun.mahajan@gmail.com"]
        let subject = "From Swift Player App"
        let messageBody = ""
        
        let configuredMailComposeViewController = configureMailComposeViewController(recepients: receipients, subject: subject, messageBody: messageBody)
        
        if canSendMail() {
            self.present(configuredMailComposeViewController, animated: true, completion: nil)
        } else {
            showSendMailErrorAlert()
        }
    }
    
    @IBAction func mailToKaran(_ sender: UIButton) {
        let receipients = ["karangupta661@yahoo.in"]
        let subject = "From Swift Player App"
        let messageBody = ""
        
        let configuredMailComposeViewController = configureMailComposeViewController(recepients: receipients, subject: subject, messageBody: messageBody)
        
        if canSendMail() {
            self.present(configuredMailComposeViewController, animated: true, completion: nil)
        } else {
            showSendMailErrorAlert()
        }
    }
    
    @IBAction func mailToVishav(_ sender: UIButton) {
        let receipients = ["14mca013@smvdu.ac.in"]
        let subject = "From Swift Player App"
        let messageBody = ""
        
        let configuredMailComposeViewController = configureMailComposeViewController(recepients: receipients, subject: subject, messageBody: messageBody)
        
        if canSendMail() {
            self.present(configuredMailComposeViewController, animated: true, completion: nil)
        } else {
            showSendMailErrorAlert()
        }
    }
    

  }

//*****************************************************************
// MARK: - MFMailComposeViewController Delegate
//*****************************************************************

extension AboutViewController: MFMailComposeViewControllerDelegate {
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    func canSendMail() -> Bool {
        return MFMailComposeViewController.canSendMail()
    }
    
    func configureMailComposeViewController(recepients: [String], subject: String, messageBody: String) -> MFMailComposeViewController {
        
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(recepients)
        mailComposerVC.setSubject(subject)
        mailComposerVC.setMessageBody(messageBody, isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
        sendMailErrorAlert.show()
    }
}
