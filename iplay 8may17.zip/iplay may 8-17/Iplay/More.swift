//
//  More.swift
//  Iplay
//
//  Created by Student1 on 28/04/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

class More: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func myHandler(alert: UIAlertAction)
    {
          exit(0)
    }
    
    @IBAction func exitApp(_ sender: UIBarButtonItem) {
        
        let alert = UIAlertController (title: "Exiting........", message: "Exiting from iplay.", preferredStyle: .alert)
        let ok = UIAlertAction (title: "Ok", style: .default, handler: myHandler)
        let cancel = UIAlertAction (title: "Cancel", style: .default, handler: nil)
        
        alert.addAction(cancel)
        alert.addAction(ok)
        present(alert, animated:true)
        
        
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
