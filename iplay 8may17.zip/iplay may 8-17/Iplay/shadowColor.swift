//
//  shadowColor.swift
//  Iplay
//
//  Created by Student2 on 31/03/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import Foundation
import UIKit

let shadowColor:CGFloat=155.0/255.0
