//
//  DesignabbleButton.swift
//  Iplay
//
//  Created by Student2 on 31/03/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

@IBDesignable class DesignabbleButton: BounceButton {
    
   
    
    
    
    @IBInspectable var borderwidth:CGFloat=0.0{
        didSet{ self.layer.borderWidth = borderwidth}
    }

    @IBInspectable var bordercolor:UIColor=UIColor.clear
        {
        didSet { self.layer.borderColor=bordercolor.cgColor}
    
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0
        {
        didSet { self.layer.cornerRadius = cornerRadius}
    }

}
