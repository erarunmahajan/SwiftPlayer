//
//  fbViewController.swift
//  Iplay
//
//  Created by Student2 on 05/04/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

//import UIKit

//class fbViewController: UIViewController {
    import UIKit
 
    import Social
    import AVFoundation
    class fbViewController: UIViewController , FBSDKLoginButtonDelegate {
        
        @IBAction func play(_ sender: AnyObject) {
        }
        @IBAction func fb(_ sender: AnyObject) {
            let fb : SLComposeViewController =
                SLComposeViewController(forServiceType:
                    SLServiceTypeFacebook)
            self.present(fb, animated:true,completion: nil)
        }
        
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            let loginbutton=FBSDKLoginButton()
            loginbutton.center=self.view.center
            view.addSubview(loginbutton)
            loginbutton.delegate=self
            
        }
        func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
            if error != nil
            {
                print("something went wrong..\(error)")
                return
            }
            print("successfully logged in facebook")
        }
        func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
            print("successfully loggut out of facebook")
        }
        
}
