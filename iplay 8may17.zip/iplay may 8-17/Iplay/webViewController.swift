//
//  webViewController.swift
//  Iplay
//
//  Created by Student2 on 31/03/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit

class webViewController: UIViewController {

    @IBOutlet var webview: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        webview.loadRequest(NSURLRequest(url:NSURL(string: "http://google.com")! as URL) as URLRequest)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func ReFresh(_ sender: AnyObject) {webview.reload()

    }
    
    @IBAction func forward(_ sender: AnyObject) {
        webview.goForward()
    }
   
    
    
    @IBAction func back(_ sender: AnyObject) {
        if(webview.canGoBack) {
            //Go back in webview history
            webview.goBack()
        } else {
            //Pop view controller to preview view controller
            self.navigationController?.popViewController(animated: true)
        }
    
    }
    
    
    
//    func myHandler(alert: UIAlertAction)
//    {
//        
//        exit(0)
//    }
//    
//    @IBAction func exitApp(_ sender: UIBarButtonItem) {
//        
//        let alert = UIAlertController (title: "Exiting........", message: "Exiting from iplay.", preferredStyle: .alert)
//        let ok = UIAlertAction (title: "Ok", style: .default, handler: myHandler)
//        let cancel = UIAlertAction (title: "Cancel", style: .default, handler: nil)
//        
//        alert.addAction(cancel)
//        alert.addAction(ok)
//        present(alert, animated:true)
//        
//      }  
//        
    
    

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
