//
//  Setting_classViewController.swift
//  Iplay
//
//  Created by Student2 on 27/03/17.
//  Copyright © 2017 "CUJ""SMVDU". All rights reserved.
//

import UIKit
import MediaPlayer
class Setting_classViewController: UIViewController {
    
    @IBOutlet var activity: UIActivityIndicatorView!
    
    @IBAction func ContactUs(_ sender: AnyObject) {
        if let url = URL(string: "https://docs.google.com/forms/d/e/1FAIpQLScMbi8pDMR6DDOClw4Q_MJqmYjOjENM-XWB6TtEcZ1Q6EXxnA/viewform?usp=sf_link"){UIApplication.shared.openURL(url)}

    }
    
    @IBAction func sleepMode(_ sender: DesignabbleButton) {
  
    }
    
    
    
    @IBAction func eq(_ sender: DesignabbleButton) {
//        UIApplication.shared.openURL(URL(string:"prefs:root=General&path=About")!)
//        UIApplication.shared.openURL(URL(string:UIApplicationOpenSettingsURLString)!)
        UIApplication.shared.openURL(URL(string:"App-Prefs:root=MUSIC&path=EQ")!)
    }
    func myHandler(alert: UIAlertAction)
    {
       
        let VC : ViewController? = ViewController()
       VC?.mp.pause()
        exit(0)
    }
    
    
    @IBAction func exitApp(_ sender: AnyObject)
    {
        
        
            
            let alert = UIAlertController (title: "Exiting........", message: "Exiting from iplay.", preferredStyle: .alert)
            let ok = UIAlertAction (title: "Ok", style: .default, handler: myHandler)
            let cancel = UIAlertAction (title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(cancel)
            alert.addAction(ok)
            present(alert, animated:true)
        
        
        
    }
    
    
    @IBAction func CheckUpdates(_ sender: UIButton) {
        
        activity.isHidden = false
        activity.startAnimating()
            let alert = UIAlertController (title: "iPlay Updates", message: "Application is already updated to its latest  version!!", preferredStyle: .alert)
        let ok = UIAlertAction (title: "Ok", style: .default, handler: { (action: UIAlertAction!) in self.activity.isHidden = true; self.activity.stopAnimating()})
            alert.addAction(ok)
            present(alert, animated:true)

    }
    
    
    
    
    @IBAction func clear(_ sender: DesignabbleButton) {
        
        URLCache.shared.removeAllCachedResponses()
        
        let alert = UIAlertController (title: "Clearing Cache", message: "Application Cache has been cleared!!", preferredStyle: .alert)
        let ok = UIAlertAction (title: "Ok", style: .default, handler: nil)
        
        alert.addAction(ok)
        
        present(alert, animated:true)
        
        
    }
    
  /*  @IBAction func clear(_ sender: UIButton) {
        
        URLCache.shared.removeAllCachedResponses()
        
        let alert = UIAlertController (title: "Clearing Cache", message: "Application Cache has been cleared!!", preferredStyle: .alert)
        let ok = UIAlertAction (title: "Ok", style: .default, handler: nil)
        
        alert.addAction(ok)
        
    }*/
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
